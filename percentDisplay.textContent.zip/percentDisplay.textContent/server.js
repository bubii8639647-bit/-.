const express = require('express');
const multer = require('multer');
const archiver = require('archiver');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 3000;

// สร้างโฟลเดอร์สำหรับเก็บไฟล์ถ้ายังไม่มี
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const PACKS_DIR = path.join(__dirname, 'packs');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR);
if (!fs.existsSync(PACKS_DIR)) fs.mkdirSync(PACKS_DIR);

// ตั้งค่า Multer สำหรับพักไฟล์ชั่วคราว
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOADS_DIR),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage: storage });

// เสิร์ฟหน้าเว็บ Frontend
app.use(express.static(path.join(__dirname, 'public')));
// เปิดให้ดาวน์โหลดไฟล์แพ็คจากโฟลเดอร์ packs
app.use('/download', express.static(PACKS_DIR));

// API สำหรับอัปโหลดและแพ็คไฟล์
app.post('/api/upload', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'กรุณาเลือกไฟล์' });
    }

    const fileUniqueId = uuidv4();
    const originalName = req.file.originalname;
    const ext = path.extname(originalName);
    const baseName = path.basename(originalName, ext);
    
    // ตั้งชื่อไฟล์แพ็คใหม่เป็น ZIP
    const packFileName = `${baseName}-${fileUniqueId}.zip`;
    const packOutputPath = path.join(PACKS_DIR, packFileName);
    
    const output = fs.createWriteStream(packOutputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => {
        // ลบไฟล์ต้นฉบับที่อัปโหลดเข้ามาเพื่อประหยัดพื้นที่ (เหลือไว้แค่ไฟล์ ZIP ที่แพ็คแล้ว)
        fs.unlinkSync(req.file.path);

        // สร้าง Link สำหรับดาวน์โหลดตรง
        const downloadLink = `${req.protocol}://${req.get('host')}/download/${packFileName}`;
        
        res.json({
            success: true,
            fileName: packFileName,
            downloadUrl: downloadLink
        });
    });

    archive.on('error', (err) => {
        res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาดในการแพ็คไฟล์' });
    });

    archive.pipe(output);
    // ใส่ไฟล์เข้าไปใน ZIP (เปลี่ยนชื่อใน ZIP ให้เป็นชื่อดั้งเดิมของผู้ใช้)
    archive.file(req.file.path, { name: originalName });
    await archive.finalize();
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
